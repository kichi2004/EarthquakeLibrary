﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using EarthquakeLibrary.Core;

namespace EarthquakeLibrary.EEW
{
    /// <summary>
    /// 緊急地震速報関連
    /// </summary>
    public static class EEW
    {
        public class EEWWatcher
        {
            /// <summary>
            /// EEWWatcherを初期化します。
            /// </summary>
            /// <param name="interval">取得間隔（秒）</param>
            public EEWWatcher(ushort interval) : this()
                => this.timer.Interval = interval * 1000;
            /// <summary>
            /// EEWWatcherを初期化します。
            /// </summary>
            public EEWWatcher()
            {
                this.timer = new System.Timers.Timer() { Interval = 1000 };
                this.SetTime();
                this.timer.Elapsed += this.Timer_Elapsed;
            }

            private System.Timers.Timer timer;
            private int c;
            private DateTime time;
            private void Timer_Elapsed(object sender, EventArgs e)
            {
                if (this.c == this.timer.Interval / 5 * 18) SetTime();

                this.c++;
            }
            public void SetTime()
            => this.time = DateTime.ParseExact(new WebClient().DownloadString("http://ntp-a1.nict.go.jp/cgi-bin/time"), "ddd MMM dd HH:mm:ss yyyy JST\n", DateTimeFormatInfo.InvariantInfo, DateTimeStyles.None);

        }
    }

    /// <summary>
    /// 緊急地震速報データ
    /// </summary>
    internal class EEW_Data
    {
        /// <summary>
        /// 情報発表時刻
        /// </summary>
        public DateTime ReportTime { get; internal set; }
        /// <summary>
        /// 報番号
        /// </summary>
        public int ReoprtNum { get; internal set; }
        /// <summary>
        /// 最終報か
        /// </summary>
        public bool IsFinal { get; internal set; }
        /// <summary>
        /// 震源地
        /// </summary>
        public string Epicenter { get; internal set; }
        /// <summary>
        /// 震央コード
        /// </summary>
        public int RegionCode { get; internal set; }
        /// <summary>
        /// 深さ
        /// </summary>
        public int Depth { get; set; }
        /// <summary>
        /// マグニチュード
        /// </summary>
        public float Magnitude { get; set; }
        /// <summary>
        /// 最大震度
        /// </summary>
        public JmaIntensity MaxIntensity { get; internal set; }
        /// <summary>
        /// 警報／予報／特別警報
        /// </summary>
        public WarningType Warning { get; internal set; }
        /// <summary>
        /// 震央座標
        /// </summary>
        public Location CenterLocation { get; internal set; }
        /// <summary>
        /// 訓練か
        /// </summary>
        public bool IsTraning { get; internal set; }
        /// <summary>
        /// 地震ID
        /// </summary>
        public long QuakeId { get; internal set; }
        /// <summary>
        /// 設定値の推定震度
        /// </summary>
        public JmaIntensity EstimatedIntensity { get; internal set; }
        /// <summary>
        /// 都府県ごとの予想震度
        /// </summary>
        public IEnumerable<Area> Areas { get; internal set; }

        /// <summary>
        /// 推定地域
        /// </summary>
        public class Area
        {
            public string Prefecture { get; internal set; }
            public JmaIntensity Intensity { get; internal set; }
        }
    }
    /// <summary>
    /// 緊急地震速報の種類
    /// </summary>
    public enum WarningType
    {
        /// <summary>
        /// なし／不明
        /// </summary>
        Unknown = -1,
        /// <summary>
        /// 予報
        /// </summary>
        Foreacst = 0,
        /// <summary>
        /// 警報
        /// </summary>
        Warning = 1,
        Emergency = 2,
        /// <summary>
        /// 特別警報
        /// </summary>
        EmergencyWarning = Warning | Emergency
    }

}
