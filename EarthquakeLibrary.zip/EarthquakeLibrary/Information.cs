﻿// ReSharper disable InconsistentNaming

using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using EarthquakeLibrary.Core;
using HtmlAgilityPack;
using static EarthquakeLibrary.Information.EarthquakeInformation;

namespace EarthquakeLibrary.Information
{
    public static class Information
    {

        /// <summary>
        /// 発生日時からYahoo!地震情報のURLを生成します。
        /// </summary>
        /// <param name="dateTime">発生日時</param>
        /// <returns></returns>
        public static string GenerateYahooUrl(DateTime dateTime)
            => $"https://typhoon.yahoo.co.jp/weather/earthquake/{dateTime:yyyyMMddHHmmss}.html";

        /// <summary>
        /// 発生日時からYahoo!地震情報のURLを生成します。
        /// </summary>
        /// <param name="dateTime">発生日時</param>
        /// <returns></returns>
        public static string GenerateYahooUrl(DateTime? dateTime) =>
            dateTime != null ? GenerateYahooUrl(dateTime.Value) : YahooUrl;

        /// <summary>
        /// Yahoo!天気・災害：地震 のトップページのURL
        /// </summary>
        public const string YahooUrl = "https://typhoon.yahoo.co.jp/weather/earthquake/";

        /// <summary>
        /// Yahoo!天気・災害：地震 のトップページのURL:URI
        /// </summary>
        public static Uri YahooUri = new Uri("https://typhoon.yahoo.co.jp/weather/earthquake/");

        /// <summary>
        /// Yahoo!天気・災害から最新の地震情報を取得します。
        /// </summary>
        /// <returns></returns>
        public static NewEarthquakeInformation GetNewEarthquakeInformationFromYahoo()
            => GetNewEarthquakeInformationFromYahoo(YahooUri);

        /// <summary>
        /// Yahoo!天気・災害から最新地震情報を取得します。
        /// </summary>
        /// <param name="uri">URL</param>
        /// <returns></returns>
        public static NewEarthquakeInformation GetNewEarthquakeInformationFromYahoo(Uri uri)
        {
            string source;
            try {
                using (var wc = new WebClient() { Encoding = Encoding.UTF8 }) {
                    source = wc.DownloadString(uri);
                }
            } catch (WebException) {
                return null;
            }
            #region 正規表現
            var date_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>発生時刻</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var date2_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>情報発表時刻</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var region_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>震源地</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small><a .*?>(.*?)</a></small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var depth_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>深さ</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var mag_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>マグニチュード</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var int_match = new Regex("<td bgcolor=\"#ffffff\" width=10% align=center><small>震度(.*?)</small></td>",
                RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var info_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>情報</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var lon_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>経度</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var lat_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>緯度</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var url_match =
                new Regex(
                    "<img src=\"(http(s)?://([\\w-]+\\.)+[\\w-]+(/[\\w- ./?%&=]*)?)\" width=.+ height=.+ alt=\"地震画像\">",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var match =
                new Regex(
                    "<td><a href=\"/weather/jp/earthquake(?<url>.*?)\">(?<time>.*?)</a></td>.*?<td>(?<time2>.*?)</td>.*?<td align=center>(?<area>.*?)</td>.*?<td align=center>(?<mag>.*?)</td>.*?<td align=center>(?<sind>.*?)</td>.*?</tr>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source).NextMatch();
            #endregion
            var location = new Location();
            bool plus = lon_match.Groups[1].Value.Contains("東経");
            if (plus)
                location.Longitude = float.Parse(lon_match.Groups[1].Value.Substring(2).Replace("度", ""));
            else
                location.Longitude = -( float.Parse(lon_match.Groups[1].Value.Substring(2).Replace("度", "")) );
            plus = lat_match.Groups[1].Value.Contains("北緯");
            if (plus)
                location.Latitude = float.Parse(lat_match.Groups[1].Value.Substring(2).Replace("度", ""));
            else
                location.Latitude = -( float.Parse(lat_match.Groups[1].Value.Substring(2).Replace("度", "")) );

            string iUrl = url_match.Success ? url_match.Groups[1].Value : null;
            var rtn = new NewEarthquakeInformation(origin_time: date_match.Groups[1].Value,
                announced_time: date2_match.Groups[1].Value, epicenter: region_match.Groups[1].Value,
                magnitude: mag_match.Groups[1].Value, intensity: int_match.Groups[1].Value,
                Lat: null, Lon: null, depth: depth_match.Groups[1].Value, message: info_match.Groups[1].Value, image_url: iUrl)
            {
                Info_url = new Uri("https://typhoon.yahoo.co.jp/weather/earthquake/"),
                Location = location,
            };

            var oldinfo = new List<OldEarthquakeInformation>();
            if (match.Success)
                for (int i = 0; i <= 8; i++) {
                    var info = new OldEarthquakeInformation
                {
                        Origin_time = DateTime.ParseExact(match.Groups["time"].Value, "yyyy年M月d日 H時m分ごろ",
                        DateTimeFormatInfo.InvariantInfo, DateTimeStyles.NoCurrentDateDefault),
                        Announced_time = DateTime.ParseExact(match.Groups["time2"].Value, "yyyy年M月d日 H時m分",
                        DateTimeFormatInfo.InvariantInfo, DateTimeStyles.NoCurrentDateDefault)
                    };
                    string epicenter = match.Groups["area"].Value;
                    info.Epicenter = epicenter == "---" ? null : epicenter;

                    string magnitude = match.Groups["mag"].Value;
                    info.Magnitude = magnitude == "---" ? (float?) null : float.Parse(magnitude);

                    string intensity = match.Groups["sind"].Value;
                    info.MaxIntensity = intensity == "---" ? JmaIntensity.Unknown : intensity.ToJmaIntensity();

                    info.Info_url = new Uri("https://typhoon.yahoo.co.jp/weather/jp/earthquake" + match.Groups["url"].Value);
                    oldinfo.Add(info);
                    if (i != 8)
                        match = match.NextMatch();
                }
            rtn.Oldinfo = oldinfo.AsEnumerable();
            var doc = new HtmlDocument();
            doc.LoadHtml(source);

            var htmlNode = doc.DocumentNode.SelectSingleNode(@"//table[@class=""yjw_table""]")
                .ChildNodes.Where((a, i) => i % 2 == 1);
            rtn.Shindo = htmlNode.Select(t => {
                var info = new EarthquakeInformation.ShindoInformation();
                var tag = t.ChildNodes;
                info.Intensity = tag[1].InnerText.ToJmaIntensity();
                info.Place = tag[3].ChildNodes[1].ChildNodes
                .Where((a, i) => i % 2 == 1)
                .Select(a => a.ChildNodes)
                .Select(a => new EarthquakeInformation.ShindoPlace {
                    Prefecture = a[1].InnerText.Replace("\n", ""),
                    Place = a[3].InnerText.Split(new char[] { '\n', ' ' })
                        .Select(x => x.Trim()).Where(x => !string.IsNullOrWhiteSpace(x)).AsParallel()
                });
                return info;
            });
            return rtn;
        }

        /// <summary>
        /// Yahoo!天気・災害から最新の地震情報を取得します。
        /// </summary>
        /// <returns></returns>
        public static async Task<NewEarthquakeInformation> GetNewEarthquakeInformationFromYahooAsync()
            => await GetNewEarthquakeInformationFromYahooAsync(YahooUri);

        /// <summary>
        /// Yahoo!天気・災害から最新地震情報を取得します。
        /// </summary>
        /// <param name="uri">URL</param>
        /// <returns></returns>
        public static async Task<NewEarthquakeInformation> GetNewEarthquakeInformationFromYahooAsync(Uri uri)
        {
            string source;
            try {
                using (var wc = new WebClient() { Encoding = Encoding.UTF8 }) {
                    source = await wc.DownloadStringTaskAsync(uri);
                }
            } catch (WebException) {
                return null;
            }
            #region 正規表現
            var date_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>発生時刻</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var date2_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>情報発表時刻</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var region_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>震源地</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small><a .*?>(.*?)</a></small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var depth_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>深さ</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var mag_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>マグニチュード</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var int_match = new Regex("<td bgcolor=\"#ffffff\" width=10% align=center><small>震度(.*?)</small></td>",
                RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var info_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>情報</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var lon_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>経度</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var lat_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>緯度</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var url_match =
                new Regex(
                    "<img src=\"(http(s)?://([\\w-]+\\.)+[\\w-]+(/[\\w- ./?%&=]*)?)\" width=.+ height=.+ alt=\"地震画像\">",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var match =
                new Regex(
                    "<td><a href=\"/weather/jp/earthquake(?<url>.*?)\">(?<time>.*?)</a></td>.*?<td>(?<time2>.*?)</td>.*?<td align=center>(?<area>.*?)</td>.*?<td align=center>(?<mag>.*?)</td>.*?<td align=center>(?<sind>.*?)</td>.*?</tr>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source).NextMatch();
            #endregion
            var location = new Location();
            bool plus = lon_match.Groups[1].Value.Contains("東経");
            if (plus)
                location.Longitude = float.Parse(lon_match.Groups[1].Value.Substring(2).Replace("度", ""));
            else
                location.Longitude = -( float.Parse(lon_match.Groups[1].Value.Substring(2).Replace("度", "")) );
            plus = lat_match.Groups[1].Value.Contains("北緯");
            if (plus)
                location.Latitude = float.Parse(lat_match.Groups[1].Value.Substring(2).Replace("度", ""));
            else
                location.Latitude = -( float.Parse(lat_match.Groups[1].Value.Substring(2).Replace("度", "")) );
            var rtn = new NewEarthquakeInformation(origin_time: date_match.Groups[1].Value,
                announced_time: date2_match.Groups[1].Value, epicenter: region_match.Groups[1].Value,
                magnitude: mag_match.Groups[1].Value, intensity: int_match.Groups[1].Value,
                Lat: null, Lon: null, depth: depth_match.Groups[1].Value, message: info_match.Groups[1].Value, image_url: url_match.Groups[1].Value)
            {
                Info_url = new Uri("https://typhoon.yahoo.co.jp/weather/earthquake/"),
                Location = location,
            };

            var oldinfo = new List<OldEarthquakeInformation>();
            if (match.Success)
                for (int i = 0; i <= 8; i++) {
                    var info = new OldEarthquakeInformation
                {
                        Origin_time = DateTime.ParseExact(match.Groups["time"].Value, "yyyy年M月d日 H時m分ごろ",
                        DateTimeFormatInfo.InvariantInfo, DateTimeStyles.NoCurrentDateDefault),
                        Announced_time = DateTime.ParseExact(match.Groups["time2"].Value, "yyyy年M月d日 H時m分",
                        DateTimeFormatInfo.InvariantInfo, DateTimeStyles.NoCurrentDateDefault)
                    };
                    string epicenter = match.Groups["area"].Value;
                    info.Epicenter = epicenter == "---" ? null : epicenter;

                    string magnitude = match.Groups["mag"].Value;
                    info.Magnitude = magnitude == "---" ? (float?) null : float.Parse(magnitude);

                    string intensity = match.Groups["sind"].Value;
                    info.MaxIntensity = intensity == "---" ? JmaIntensity.Unknown : intensity.ToJmaIntensity();

                    info.Info_url = new Uri("https://typhoon.yahoo.co.jp/weather/jp/earthquake" + match.Groups["url"].Value);
                    oldinfo.Add(info);
                    if (i != 8)
                        match = match.NextMatch();
                }
            rtn.Oldinfo = oldinfo.AsEnumerable();
            var doc = new HtmlDocument();
            doc.LoadHtml(source);

            var htmlNode = doc.DocumentNode.SelectSingleNode(@"//table[@class=""yjw_table""]")
                .ChildNodes.Where((a, i) => i % 2 == 1);
            rtn.Shindo = htmlNode.Select(t => {
                var info = new EarthquakeInformation.ShindoInformation();
                var tag = t.ChildNodes;
                info.Intensity = tag[1].InnerText.ToJmaIntensity();
                info.Place = tag[3].ChildNodes[1].ChildNodes
                .Where((a, i) => i % 2 == 1)
                .Select(a => a.ChildNodes)
                .Select(a => new EarthquakeInformation.ShindoPlace {
                    Prefecture = a[1].InnerText.Replace("\n", ""),
                    Place = a[3].InnerText.Split(new char[] { '\n', ' ' })
                        .Select(x => x.Trim()).Where(x => !string.IsNullOrWhiteSpace(x)).AsParallel()
                });
                return info;
            });
            return rtn;
        }

        /// <summary>
        /// Yahoo!天気・災害から地震情報を取得します。
        /// </summary>
        /// <param name="uri">URL</param>
        /// <returns></returns>
        public static EarthquakeInformation GetEarthquakeInformationFromYahoo(Uri uri)
        {
            string source;
            try {
                using (var wc = new WebClient() { Encoding = Encoding.UTF8 }) {
                    source = wc.DownloadString(uri);
                }
            } catch (WebException) {
                return null;
            }
            #region 正規表現
            var date_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>発生時刻</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var date2_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>情報発表時刻</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var region_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>震源地</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small><a .*?>(.*?)</a></small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var depth_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>深さ</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var mag_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>マグニチュード</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var int_match = new Regex("<td bgcolor=\"#ffffff\" width=10% align=center><small>震度(.*?)</small></td>",
                RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var info_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>情報</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var lon_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>経度</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var lat_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>緯度</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var url_match =
                new Regex(
                    "<img src=\"(http(s)?://([\\w-]+\\.)+[\\w-]+(/[\\w- ./?%&=]*)?)\" width=.+ height=.+ alt=\"地震画像\">",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            #endregion
            var location = new Location();
            bool plus = lon_match.Groups[1].Value.Contains("東経");
            if (plus)
                location.Longitude = float.Parse(lon_match.Groups[1].Value.Substring(2).Replace("度", ""));
            else
                location.Longitude = -( float.Parse(lon_match.Groups[1].Value.Substring(2).Replace("度", "")) );
            plus = lat_match.Groups[1].Value.Contains("北緯");
            if (plus)
                location.Latitude = float.Parse(lat_match.Groups[1].Value.Substring(2).Replace("度", ""));
            else
                location.Latitude = -( float.Parse(lat_match.Groups[1].Value.Substring(2).Replace("度", "")) );
            var rtn = new EarthquakeInformation(origin_time: date_match.Groups[1].Value,
                announced_time: date2_match.Groups[1].Value, epicenter: region_match.Groups[1].Value,
                magnitude: mag_match.Groups[1].Value, intensity: int_match.Groups[1].Value,
                Lat: null, Lon: null, depth: depth_match.Groups[1].Value, message: info_match.Groups[1].Value, image_url: url_match.Groups[1].Value)
            {
                Info_url = new Uri("https://typhoon.yahoo.co.jp/weather/earthquake/"),
                Location = location,
            };

            var doc = new HtmlDocument();
            doc.LoadHtml(source);

            var htmlNode = doc.DocumentNode.SelectSingleNode(@"//table[@class=""yjw_table""]")
                .ChildNodes.Where((a, i) => i % 2 == 1);
            rtn.Shindo = htmlNode.Select(t => {
                var info = new EarthquakeInformation.ShindoInformation();
                var tag = t.ChildNodes;
                info.Intensity = tag[1].InnerText.ToJmaIntensity();
                info.Place = tag[3].ChildNodes[1].ChildNodes
                .Where((a, i) => i % 2 == 1)
                .Select(a => a.ChildNodes)
                .Select(a => new EarthquakeInformation.ShindoPlace {
                    Prefecture = a[1].InnerText.Replace("\n", ""),
                    Place = a[3].InnerText.Split(new char[] { '\n', ' ' })
                        .Select(x => x.Trim()).Where(x => !string.IsNullOrWhiteSpace(x)).AsParallel()
                });
                return info;
            });
            return rtn;
        }

        /// <summary>
        /// Yahoo!天気・災害から地震情報を取得します。
        /// </summary>
        /// <param name="uri">URL</param>
        /// <returns></returns>
        public static async Task<EarthquakeInformation> GetEarthquakeInformationFromYahooAsync(Uri uri)
        {
            string source;
            try {
                using (var wc = new WebClient() { Encoding = Encoding.UTF8 }) {
                    source = await wc.DownloadStringTaskAsync(uri);
                }
            } catch (WebException) {
                return null;
            }
            #region 正規表現
            var date_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>発生時刻</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var date2_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>情報発表時刻</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var region_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>震源地</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small><a .*?>(.*?)</a></small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var depth_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>深さ</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var mag_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>マグニチュード</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var int_match = new Regex("<td bgcolor=\"#ffffff\" width=10% align=center><small>震度(.*?)</small></td>",
                RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var info_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>情報</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var lon_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>経度</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var lat_match =
                new Regex(
                    "<td bgcolor=\"#eeeeee\" width=30% align=center><small>緯度</small></td>.*?<td bgcolor=\"#ffffff\" width=70%><small>(.*?)</small></td>",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
            var url_match =
                new Regex(
                    "<img src=\"(http(s)?://([\\w-]+\\.)+[\\w-]+(/[\\w- ./?%&=]*)?)\" width=.+ height=.+ alt=\"地震画像\">",
                    RegexOptions.IgnoreCase | RegexOptions.Singleline).Match(source);
           #endregion
            var location = new Location();
            bool plus = lon_match.Groups[1].Value.Contains("東経");
            if (plus)
                location.Longitude = float.Parse(lon_match.Groups[1].Value.Substring(2).Replace("度", ""));
            else
                location.Longitude = -( float.Parse(lon_match.Groups[1].Value.Substring(2).Replace("度", "")) );
            plus = lat_match.Groups[1].Value.Contains("北緯");
            if (plus)
                location.Latitude = float.Parse(lat_match.Groups[1].Value.Substring(2).Replace("度", ""));
            else
                location.Latitude = -( float.Parse(lat_match.Groups[1].Value.Substring(2).Replace("度", "")) );
            var rtn = new EarthquakeInformation(origin_time: date_match.Groups[1].Value,
                announced_time: date2_match.Groups[1].Value, epicenter: region_match.Groups[1].Value,
                magnitude: mag_match.Groups[1].Value, intensity: int_match.Groups[1].Value,
                Lat: null, Lon: null, depth: depth_match.Groups[1].Value, message: info_match.Groups[1].Value, image_url: url_match.Groups[1].Value)
            {
                Info_url = new Uri("https://typhoon.yahoo.co.jp/weather/earthquake/"),
                Location = location,
            };

            var doc = new HtmlDocument();
            doc.LoadHtml(source);

            var htmlNode = doc.DocumentNode.SelectSingleNode(@"//table[@class=""yjw_table""]")
                .ChildNodes.Where((a, i) => i % 2 == 1);
            rtn.Shindo = htmlNode.Select(t => {
                var info = new EarthquakeInformation.ShindoInformation();
                var tag = t.ChildNodes;
                info.Intensity = tag[1].InnerText.ToJmaIntensity();
                info.Place = tag[3].ChildNodes[1].ChildNodes
                .Where((a, i) => i % 2 == 1)
                .Select(a => a.ChildNodes)
                .Select(a => new EarthquakeInformation.ShindoPlace {
                    Prefecture = a[1].InnerText.Replace("\n", ""),
                    Place = a[3].InnerText.Split(new char[] { '\n', ' ' })
                        .Select(x => x.Trim()).Where(x => !string.IsNullOrWhiteSpace(x)).AsParallel()
                });
                return info;
            });
            return rtn;
        }



        public static IEnumerable<P2PShindoInformation> ToP2PShindoInformation(this IEnumerable<ShindoInformation> info)
        {
            return info
                .SelectMany(a => a.Place
                    .Select(b => new { a.Intensity, b.Prefecture, b.Place }))
                .GroupBy(a => a.Prefecture)
                .Select(a => new P2PShindoInformation {
                    Prefecture = a.Key, Place = a.Select(b =>
                      new P2PShindoPlace { Intensity = b.Intensity, Place = b.Place })
                });
        }
        public static IEnumerable<P2PShindoInformation> ToP2PShindoInformation<T>(T info,
            Func<T, IEnumerable<ShindoInformation>> selector)
            => ToP2PShindoInformation(selector(info));
        public static IEnumerable<P2PShindoInformation> ToP2PShindoInformation(EarthquakeInformation info)
            => ToP2PShindoInformation(info.Shindo);
    }

    ///<summary>最新の地震情報</summary>
    public class NewEarthquakeInformation : EarthquakeInformation
    {
        public NewEarthquakeInformation() { }

        public NewEarthquakeInformation(string origin_time, string announced_time, string epicenter,
            string magnitude, string intensity, string Lat, string Lon, string depth, string message, string image_url)
            : base(origin_time, announced_time, epicenter,
            magnitude, intensity, Lat, Lon, depth, message, image_url)
        {
        }

        public IEnumerable<OldEarthquakeInformation> OldInformation { get; internal set; }

    }

    ///<summary>地震情報</summary>
    public class EarthquakeInformation : OldEarthquakeInformation
    {
        public EarthquakeInformation() { }

        public EarthquakeInformation(string origin_time, string announced_time, string epicenter, string magnitude, string intensity, string Lat, string Lon,
            string depth, string message, string image_url)
        {
            this.Origin_time = DateTime.ParseExact(origin_time, "yyyy年M月d日 H時m分ごろ", DateTimeFormatInfo.InvariantInfo, DateTimeStyles.NoCurrentDateDefault);

            this.Announced_time = DateTime.ParseExact(announced_time, "yyyy年M月d日 H時m分", DateTimeFormatInfo.InvariantInfo, DateTimeStyles.NoCurrentDateDefault);

            if (epicenter == "---") this.Epicenter = null;
            else this.Epicenter = epicenter;

            if (magnitude == "---") this.Magnitude = null;
            else this.Magnitude = float.Parse(magnitude);

            if (intensity == "---") this.MaxIntensity = JmaIntensity.Unknown;
            else this.MaxIntensity = intensity.ToJmaIntensity();

            if (depth == "---") this.Depth = null;
            else if (depth == "ごく浅い") this.Depth = 0;
            else this.Depth = short.Parse(depth.Replace("km", ""));

            this.Image_Url = image_url == null ? null : new Uri(image_url);
            var Message = new List<MessageType>();
            if (message.Contains("津波警報等")) Message.Add(MessageType.TsunamiInformation);
            if (message.Contains("日本の沿岸では若干の海面変動")) Message.Add(MessageType.SeaLevelChange);
            if (message.Contains("この地震による津波の心配はありません。")) Message.Add(MessageType.NoTsunami);
            if (message.Contains("震源が海底の場合")) Message.Add(MessageType.TsunamiMayOccurIfEpicenterIsSea);
            if (message.Contains("今後の情報に注意")) Message.Add(MessageType.WarnToNextInfo);
            if (message.Contains("太平洋の広域")) Message.Add(MessageType.TsunamiMayOccurInWideAreaOfThePacificOcean);
            if (message.Contains("太平洋で津波発生の可能性")) {
                if (message.Contains("北西大西洋")) Message.Add(MessageType.TsunamiMayOccurInNorthWestPacificOcean);
                else Message.Add(MessageType.TsunamiMayOccurInThePacificOcean);
            }
            if (message.Contains("インド洋の広域")) Message.Add(MessageType.TsunamiMayOccurInWideAreaOfIndianTheOcean);
            if (message.Contains("インド洋")) Message.Add(MessageType.TsunamiMayOccurInTheIndianOcean);
            if (message.Contains("震源の近傍で津波発生")) Message.Add(MessageType.TsunamiMayOccurNearTheEpicenter);
            if (message.Contains("震源の近傍で小さな津波")) Message.Add(MessageType.LittleTsunamiMayOccurNearTheEpicenter_ButNoDamage);
            if (message.Contains("一般的")) Message.Add(MessageType.TsunamiMayOccurIfAboutThisScaleEarthquakeOccursInShallowSeaInGeneral);
            if (message.Contains("現在調査中")) Message.Add(MessageType.InvestigatingForTsunamiInJapan);
            if (message.Contains("日本への津波の影響は")) Message.Add(MessageType.NoTsunamiInJapan);
            if (message.Contains("緊急地震速報")) {
                bool b = false;
                if (message.Contains("最大震度は２")) Message.Add(MessageType.EEW_Int2);
                else if (message.Contains("最大震度は１")) Message.Add(MessageType.EEW_Int1);
                else if (message.Contains("震度１以上は")) Message.Add(MessageType.EEW_NoShake);
                else b = true;
                if (message.Contains("強い揺れは観測")) Message.Add(MessageType.EEW_NoStrongShake);
                else
                    if (b) Message.Add(MessageType.EEW);
            }
            this.Message = Message.ToArray();
            this.Info_url = null;
        }

        /// <summary>
        /// 座標
        /// </summary>
        public Location Location { get; set; }

        /// <summary>
        /// 深さ
        /// </summary>
        public short? Depth { get; set; }

        /// <summary>
        /// メッセージ
        /// </summary>
        public MessageType[] Message { get; set; }

        /// <summary>
        /// 過去情報
        /// </summary>
        public IEnumerable<OldEarthquakeInformation> Oldinfo { get; set; }

        /// <summary>
        /// 画像のURL
        /// </summary>
        public Uri Image_Url { get; set; }

        /// <summary>
        /// 震度情報
        /// </summary>
        public IEnumerable<ShindoInformation> Shindo { get; set; }

        /// <summary>
        /// 情報の種類
        /// </summary>
        public InformationType InformationType => (InformationType)
                    ( this.Epicenter == null ? 0 :
                        ( this.Image_Url == null ? 1 :
                            ( this.Shindo != null ? 2 : 3 ) ) );

        public class ShindoInformation
        {
            public ShindoInformation() { }
            public ShindoInformation(string shindo, IEnumerable<ShindoPlace> place)
            {
                this.Intensity = shindo.ToJmaIntensity();
                this.Place = place;
            }

            /// <summary>
            /// 震度
            /// </summary>
            public JmaIntensity Intensity { get; set; }

            /// <summary>
            /// 観測地点
            /// </summary>
            public IEnumerable<ShindoPlace> Place { get; set; }

        }
        public class ShindoPlace
        {
            public ShindoPlace() { }
            public ShindoPlace(string prefcture, IEnumerable<string> place)
            {
                this.Prefecture = prefcture;
                this.Place = place.AsParallel();
            }
            /// <summary>
            /// 都道府県
            /// </summary>
            public string Prefecture { get; set; }
            /// <summary>
            /// 観測 市区町村
            /// </summary>
            public ParallelQuery<string> Place { get; set; }
        }

        public class P2PShindoInformation
        {
            /// <summary>
            /// 都道府県
            /// </summary>
            public string Prefecture { get; set; }

            public IEnumerable<P2PShindoPlace> Place { get; set; }

        }
        public class P2PShindoPlace
        {
            /// <summary>
            /// 震度
            /// </summary>
            public JmaIntensity Intensity { get; set; }

            /// <summary>
            /// 観測 市区町村
            /// </summary>
            public ParallelQuery<string> Place { get; set; }
        }

    }

    /// <summary>
    /// 地震情報の種類
    /// </summary>
    public enum InformationType
    {
        /// <summary>
        /// 震度速報
        /// </summary>
        [Description("震度速報")]
        SesimicInfo,

        /// <summary>
        /// 震源速報
        /// </summary>
        [Description("震源速報")]
        EpicenterInfo,

        /// <summary>
        /// 地震情報
        /// </summary>
        [Description("各地の震度情報")]
        EarthquakeInfo,

        /// <summary>
        /// 震度不明
        /// </summary>
        [Description("震度不明")]
        UnknownSesimic,

        /// <summary>
        /// その他
        /// </summary>
        [Description("その他")]
        Other
    }

    /// <summary>
    /// 過去の地震情報
    /// </summary>
    public class OldEarthquakeInformation
    {
        public OldEarthquakeInformation() { }
        /// <summary>
        /// 過去の地震情報を発生時刻・発表時刻・震源地・マグニチュード・震度・URLで初期化します。
        /// </summary>
        /// <param name="origin_time">発生時刻</param>
        /// <param name="announced_time">発表時刻</param>
        /// <param name="epicenter">震源地</param>
        /// <param name="magnitude">マグニチュード</param>
        /// <param name="intensity">震度</param>
        /// <param name="uri">URL</param>
        public OldEarthquakeInformation(string origin_time, string announced_time, string epicenter, string magnitude, string intensity, string uri)
        {
            this.Origin_time = DateTime.ParseExact(origin_time, "yyyy年M月d日 H時m分ごろ", DateTimeFormatInfo.InvariantInfo, DateTimeStyles.NoCurrentDateDefault);

            this.Announced_time = DateTime.ParseExact(announced_time, "yyyy年M月d日 H時m分", DateTimeFormatInfo.InvariantInfo, DateTimeStyles.NoCurrentDateDefault);

            if (epicenter == "---") this.Epicenter = null;
            else this.Epicenter = epicenter;

            if (magnitude == "---") this.Magnitude = null;
            else this.Magnitude = float.Parse(magnitude);

            if (intensity == "---") this.MaxIntensity = JmaIntensity.Unknown;
            else this.MaxIntensity = intensity.ToJmaIntensity();

            this.Info_url = new Uri(uri, UriKind.Absolute);
        }

        /// <summary>
        /// 発生時刻
        /// </summary>
        public DateTime Origin_time { get; set; }

        /// <summary>
        /// 情報発表時刻
        /// </summary>
        public DateTime Announced_time { get; set; }

        /// <summary>
        /// 震源地
        /// </summary>
        public string Epicenter { get; set; }

        /// <summary>
        /// マグニチュード
        /// </summary>
        public float? Magnitude { get; set; }

        /// <summary>
        /// 最大震度
        /// </summary>
        public JmaIntensity MaxIntensity { get; set; }

        /// <summary>
        /// 情報のURL
        /// </summary>
        public Uri Info_url { get; set; }
    }

    /// <summary>
    /// 情報の種類
    /// </summary>
    public enum MessageType
    {
        /// <summary>
        /// 津波警報等（大津波警報・津波警報あるいは津波注意報）を発表中です。
        /// </summary>
        [Description("津波警報等（大津波警報・津波警報あるいは津波注意報）を発表中です。")]
        TsunamiInformation,
        /// <summary>
        /// この地震により、日本の沿岸では若干の海面変動があるかもしれませんが、被害の心配はありません。
        /// </summary>
        [Description("この地震により、日本の沿岸では若干の海面変動があるかもしれませんが、被害の心配はありません。")]
        SeaLevelChange,
        /// <summary>
        /// この地震による津波の心配はありません。
        /// </summary>
        [Description("この地震による津波の心配はありません。")]
        NoTsunami,
        /// <summary>
        /// 震源が海底の場合、津波が発生するおそれがあります。
        /// </summary>
        [Description("震源が海底の場合、津波が発生するおそれがあります。")]
        TsunamiMayOccurIfEpicenterIsSea,
        /// <summary>
        /// 今後の情報に注意してください。
        /// </summary>
        [Description("今後の情報に注意してください。")]
        WarnToNextInfo,
        /// <summary>
        /// 太平洋の広域に津波発生の可能性があります。
        /// </summary>
        [Description("太平洋の広域に津波発生の可能性があります。")]
        TsunamiMayOccurInWideAreaOfThePacificOcean,
        /// <summary>
        /// 太平洋で津波発生の可能性があります。
        /// </summary>
        [Description("太平洋で津波発生の可能性があります。")]
        TsunamiMayOccurInThePacificOcean,
        /// <summary>
        /// 北西太平洋で津波発生の可能性があります。
        /// </summary>
        [Description("北西太平洋で津波発生の可能性があります。")]
        TsunamiMayOccurInNorthWestPacificOcean,
        /// <summary>
        /// インド洋の広域に津波発生の可能性があります。
        /// </summary>
        [Description("インド洋の広域に津波発生の可能性があります。")]
        TsunamiMayOccurInWideAreaOfIndianTheOcean,
        /// <summary>
        /// インド洋で津波発生の可能性があります。
        /// </summary>
        [Description("インド洋で津波発生の可能性があります。")]
        TsunamiMayOccurInTheIndianOcean,
        /// <summary>
        /// 震源の近傍で津波発生の可能性があります。
        /// </summary>
        [Description("震源の近傍で津波発生の可能性があります。")]
        TsunamiMayOccurNearTheEpicenter,
        /// <summary>
        /// 震源の近傍で小さな津波発生の可能性がありますが、被害をもたらす津波の心配はありません。
        /// </summary>
        [Description("震源の近傍で小さな津波発生の可能性がありますが、被害をもたらす津波の心配はありません。")]
        LittleTsunamiMayOccurNearTheEpicenter_ButNoDamage,
        /// <summary>
        /// 一般的に、この規模の地震が海域の浅い領域で発生すると、津波が発生することがあります。
        /// </summary>
        [Description("一般的に、この規模の地震が海域の浅い領域で発生すると、津波が発生することがあります。")]
        TsunamiMayOccurIfAboutThisScaleEarthquakeOccursInShallowSeaInGeneral,
        /// <summary>
        /// 日本への津波の有無については現在調査中です。
        /// </summary>
        [Description("日本への津波の有無については現在調査中です。")]
        InvestigatingForTsunamiInJapan,
        /// <summary>
        /// この地震による日本への津波の影響はありません。
        /// </summary>
        [Description("この地震による日本への津波の影響はありません。")]
        NoTsunamiInJapan,
        /// <summary>
        /// この地震について、緊急地震速報を発表しています。
        /// </summary>
        [Description("この地震について、緊急地震速報を発表しています。")]
        EEW,
        /// <summary>
        /// この地震について、緊急地震速報を発表しています。この地震の最大震度は２でした。
        /// </summary>
        [Description("この地震について、緊急地震速報を発表しています。この地震の最大震度は２でした。")]
        EEW_Int2,
        /// <summary>
        /// この地震について、緊急地震速報を発表しています。この地震の最大震度は１でした。
        /// </summary>
        [Description("この地震について、緊急地震速報を発表しています。この地震の最大震度は１でした。")]
        EEW_Int1,
        /// <summary>
        /// この地震について、緊急地震速報を発表しています。この地震で震度１以上は観測されていません。
        /// </summary>
        [Description("この地震について、緊急地震速報を発表しています。この地震で震度１以上は観測されていません。")]
        EEW_NoShake,
        /// <summary>
        /// この地震で緊急地震速報を発表しましたが、強い揺れは観測されませんでした。
        /// </summary>
        [Description("この地震で緊急地震速報を発表しましたが、強い揺れは観測されませんでした。")]
        EEW_NoStrongShake

    }
}