﻿using EarthquakeLibrary.Core;
using EarthquakeLibrary.Information;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using EarthquakeLibrary.Tsunami;

namespace TestApp
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            var info  = Tsunami.GetForecastFromJma("http://www.jma.go.jp/jp/tsunami/info_04_20110312032045.html");
        }
    }
}